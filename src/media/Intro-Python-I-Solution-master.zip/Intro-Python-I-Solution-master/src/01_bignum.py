# Print out 2 to the 65536 power

print(2**65536)